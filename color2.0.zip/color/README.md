# weapp-color

一个基于微信小程序的游戏。

## 使用

1. 克隆此项目到本地

2. 在微信开发工具中创建项目

3. 选择该项目目录

## 工具

[官方开发文档](https://mp.weixin.qq.com/debug/wxadoc/dev/)

[开发工具下载](https://mp.weixin.qq.com/debug/wxadoc/dev/devtools/download.html)